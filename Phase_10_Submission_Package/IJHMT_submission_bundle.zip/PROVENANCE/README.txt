How this bundle was produced, and what is in it
=============================================

Target: International Journal of Heat and Mass Transfer (Elsevier, `elsarticle`,
numbered style). Every file here is generated from the project's own builders;
nothing in the bundle is hand-edited, so re-running the build reproduces it.

Sources of truth
  MANUSCRIPT/*.md          built by PAPER_PROJECT/13_Manuscript/build_manuscript.py and
                           build_calculations.py from the data package (no number is typed
                           into the text; each is read from the analysis outputs or the
                           frozen code).
  MANUSCRIPT/*.tex         built by tools/md_to_tex.py from those .md files. The .tex files
                           use \graphicspath{{figures/}} and reference the figures by name,
                           so the MANUSCRIPT folder plus MANUSCRIPT/figures/ compiles on its
                           own: pdflatex, bibtex, pdflatex, pdflatex.
  MANUSCRIPT/figures/*.pdf the eight vector renditions exported from the frozen figure
                           script (08_Experiments/make_figures.py) at 600 dpi / PDF by
                           Phase_09_Closeout and Phase_10_Submission_Package.
  MANUSCRIPT/*.pdf         previews rendered from the .md (they embed the 200-dpi PNGs the
                           project has always used, so their provenance is unchanged).
  MANUSCRIPT/highlights.txt identical to the Highlights block in the manuscript.

Supplementary material
  SUPPLEMENTARY/SUPPLEMENTARY_TABLES.xlsx  8 sheets (README, Verification,
                           PhiSweep_ellipse, Convergence_6phi, D_lambda_eps, Ablations,
                           Parameters, Production_runs), built by build_supplement.py from
                           the same analysis outputs; it satisfies the "(full table:
                           supplementary material)" promise in the Table 2 caption.

Author-owned fields still bracketed
  COVER_LETTER/*, and the same placeholders inside the .tex/.md: author names,
  affiliations, ORCID iDs, corresponding author, funding, competing interest, CRediT
  statement, and the public repository DOI for the data package. See
  CHECKLIST/AUTHOR_INPUT_REQUIRED.md. Nothing here invents those values.

Verification record
  CHECKLIST/SUBMISSION_CHECKLIST.md lists what passed the machine checks:
  tools/audit_tex.py, tools/check_crossrefs.py, tools/check_tex_commands.py,
  tools/test_md_to_tex.py, tools/verify_pdf.py (manuscript and companion), and
  Phase_08_Final_Audit/verification/final_consistency.py (0 failures: 55 references
  identical across .md/.bib/.tex/PDF, numbered in ascending order of first appearance,
  no orphan and no dangling key, structure and limits conforming).
  PROVENANCE/CODE_FREEZE_submission_2026_10_03j.json is the SHA-256 manifest of the 27
  frozen source files behind every number; its entries were re-hashed against the code.
  The .tex files have not been compiled in the environment that produced them (no TeX
  engine there); run Phase_10_Submission_Package/compile_check.sh on a machine with TeX
  Live before uploading and keep COMPILE_CHECK.txt.

Not included (by design)
  The raw research data (per-run .npz/.json outputs, convergence families, figure
  scripts, the whole code tree) belongs to the deposit package, not the manuscript
  upload. Rebuild it with:
      python3 PAPER_PROJECT/00_Project_Control/make_packages.py final
  giving PAPER_PROJECT/packages/RESEARCH_PROJECT_FINAL.zip (~45 MB, MANIFEST.json with a
  SHA-256 per file). That zip is the object to deposit in a public repository to obtain
  the DOI quoted in the Data availability statement.
