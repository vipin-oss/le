# Building this package

This is the submission package of **Multiphysics Wave Mechanics in Generalized Continua: A Constructive
Review of Theory, Energy Transport, and Interface Phenomena** (Vipin Gupta), version v1.2.

## Build

Overleaf: upload this zip as a new project and set `main.tex` as the main document. Or locally:

```
pdflatex main
bibtex   main
pdflatex main
pdflatex main
```

## Contents

- `main.tex` — master file: front matter, 17 sections, 6 appendices, declarations, bibliography.
- `frontmatter/` — title page, abstract (with keywords), notation, acronyms, declarations.
- `sections/sec01..sec17` — the review.
- `appendices/appA..appF` — equation register, balance derivations, benchmark tables, figure-status table,
  table index, reproducibility notes.
- `tables/source/` — the ten table sources that the sections `\input`.
- `figures/source/` — the 16 figure PDFs. Two further figures (`fig07-theory-map`, `fig18-taxonomy`) are
  deliberately **not** included in the text; they are declared provisional in Appendix D. They are not shipped
  here for that reason.
- `references_local.bib` — the bibliography.
- `REVIEW_CYCLES.md`, `CHANGELOG_v2.md` — the revision record.

## Verification performed before packaging

Every `\ref`/`\eqref` target resolves to a `\label`; no label is defined twice; every `\cite` key exists in
`references_local.bib`; every `\includegraphics` file is present in `figures/source/`; every `\input` file is
present; no placeholder text; header counts (17 sections, 7 appendix files, 18 figures, 8 tables) match the tree.
The package was assembled only after those checks passed on the *staged* tree.

## Known limits, stated on purpose

The manuscript's appendix D lists the status of every figure, including the two provisional ones. The benchmark
tables print measured value, reference value and residual for each check. The review does not claim case-level
results for the atlas; it claims 40 executable invariants and reports which of them are benchmarks against a
closed form.
