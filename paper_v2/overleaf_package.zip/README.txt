Overleaf package: Waves in Thermoelastic and Multiphysics Continua (review)
Compiler: pdfLaTeX (TeX Live 2023 or newer). Main file: main.tex (131 pages, custom 12pt style).
Elsevier / Physics Reports version: set main_els.tex as Main document (needs elsarticle, available on Overleaf; not yet test-compiled).
Bibliography: BibTeX (refs.bib, refs_extra.bib, refs_new.bib). Recompile twice after the first run.
Figures: figs/ (PDF from scripts/), figs_tikz/ (TikZ geometry sketches). scripts/ reproduces all numbers and data figures (Python: numpy, scipy, matplotlib, mpmath).
To verify before submission: refs_extra.bib (typed from memory), refs_new.bib (first author only for 41 entries), Bleustein1968/Gulyaev1969.
