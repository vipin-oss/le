"""Finite-difference benchmark for the Cattaneo (telegraph) heat pulse, uncoupled. Units: rho c=1, k=1, tau=1 -> c_T=1, ell=c_T tau=1.
System: th_t + q_x = 0 ; q_t + th_x/tau = -q/tau ; boundary q(0,t)=1 (step), initial zero.
Exact: Laplace th^ = (1+tau s)/(s m) exp(-x m), m=sqrt(s(1+tau s)); zero ahead of x=t."""
import numpy as np, mpmath as mp
mp.mp.dps=20
tau=1.0
def exact(x,t):
    if x>=t: return 0.0
    f=lambda s:(1+tau*s)/(s*mp.sqrt(s*(1+tau*s)))*mp.e**(-x*mp.sqrt(s*(1+tau*s)))
    return float(mp.invertlaplace(f,t,method='dehoog'))
def exact_talbot(x,t):
    f=lambda s:(1+tau*s)/(s*mp.sqrt(s*(1+tau*s)))*mp.e**(-x*mp.sqrt(s*(1+tau*s)))
    return float(mp.invertlaplace(f,t,method='talbot'))
def run(N,scheme,T=5.0,L=10.0,cfl=0.9):
    dx=L/N; x=(np.arange(N)+0.5)*dx; c=1/np.sqrt(tau); dt=cfl*dx/c; n=int(round(T/dt)); dt=T/n
    th=np.zeros(N); q=np.zeros(N)
    A=np.array([[0,1],[1/tau,0]])   # u=(th,q): u_t + A u_x = S
    lam,V=np.linalg.eig(A); Vi=np.linalg.inv(V)
    for _ in range(n):
        # source half step (exact: q decays)
        q*=np.exp(-0.5*dt/tau)
        u=np.vstack([th,q]); 
        # ghost cells: left q=1 (th zero-gradient), right zero-gradient
        ug=np.hstack([np.array([[th[0]],[2*1.0-q[0]]]),u,u[:,-1:]])
        if scheme=='upwind':
            w=Vi@ug; wn=w.copy()
            for p in range(2):
                if lam[p]>0: wn[p,1:-1]=w[p,1:-1]-lam[p]*dt/dx*(w[p,1:-1]-w[p,:-2])
                else:        wn[p,1:-1]=w[p,1:-1]-lam[p]*dt/dx*(w[p,2:]-w[p,1:-1])
            un=V@wn[:,1:-1]
        elif scheme=='LW':
            a=dt/dx; Ai=A
            f=Ai@ug
            un=ug[:,1:-1]-0.5*a*(f[:,2:]-f[:,:-2])+0.5*a*a*(Ai@(Ai@(ug[:,2:]-2*ug[:,1:-1]+ug[:,:-2])))
        elif scheme=='LF':
            a=dt/dx; f=A@ug
            un=0.5*(ug[:,2:]+ug[:,:-2])-0.5*a*(f[:,2:]-f[:,:-2])
        th,q=un[0],un[1]
        q*=np.exp(-0.5*dt/tau)
    return x,th
if __name__=='__main__':
    xs=np.linspace(0.05,4.95,200); ex=np.array([exact(xx,5.0) for xx in xs])
    ft=lambda s:(1+tau*s)/(s*mp.sqrt(s*(1+tau*s)))*mp.e**(-1.0*mp.sqrt(s*(1+tau*s)))
    st=float(mp.invertlaplace(ft,5.0,method='stehfest'))
    t20=exact_talbot(1.0,5.0); mp.mp.dps=30; t30=exact_talbot(1.0,5.0); mp.mp.dps=20
    print('x=1,t=5: de Hoog %.6f, Stehfest %.6f, Talbot %.6f (20 digits) %.6f (30 digits)'%(exact(1.0,5.0),st,t20,t30))
    print('exact theta at t=5, x=1,3,4.9:',[round(exact(xx,5.0),4) for xx in (1.0,3.0,4.9)],' jump at the front x=t: exp(-t/2tau)=%.4f'%np.exp(-5.0/2))
    for sch in ['LF','upwind','LW']:
        errs=[];Ns=[100,200,400,800,1600]
        for N in Ns:
            x,th=run(N,sch); thi=np.interp(xs,x,th); errs.append(np.mean(abs(thi-ex))*(xs[-1]-xs[0]))
        order=[np.log2(errs[i]/errs[i+1]) for i in range(len(errs)-1)]
        print(sch,'L1 errors:',['%.2e'%e for e in errs],' observed orders:',['%.2f'%o for o in order])
        # tolerance: the exact solution has a jump at the front, so L1 convergence is expected between order 1/2 and 1, not 1 or 2
        assert all(errs[i+1]<errs[i] for i in range(len(errs)-1)), sch+': L1 error not monotone in N'
        assert all(0.4<o<1.2 for o in order), sch+': observed order outside [0.4,1.2]'
    # smooth window 0.05<=x<=3.5 (away from the front): formal orders expected
    xw=np.linspace(0.05,3.5,120); exw=np.array([exact(xx,5.0) for xx in xw]); smooth={}
    for sch in ['upwind','LW']:
        errs=[]
        for N in [100,200,400,800,1600]:
            x,th=run(N,sch); errs.append(np.mean(abs(np.interp(xw,x,th)-exw))*(xw[-1]-xw[0]))
        order=[np.log2(errs[i]/errs[i+1]) for i in range(4)]; smooth[sch]=(errs,order)
        print(sch,'smooth-window (0.05<=x<=3.5) L1 errors:',['%.2e'%e for e in errs],' observed orders:',['%.2f'%o for o in order])
    assert abs(smooth['upwind'][1][-1]-1.0)<0.1 and abs(smooth['LW'][1][-1]-2.0)<0.1, 'smooth-window orders not 1 and 2'
    assert abs(smooth['upwind'][0][-1]-5.3e-4)<0.1e-4 and abs(smooth['LW'][0][-1]-3.8e-6)<0.1e-6, 'smooth-window table values changed'
    ref=dict(zip((1.0,3.0,4.9),(1.7615,0.5923,0.0959)))
    for xx,v in ref.items(): assert abs(exact(xx,5.0)-v)<5e-5, 'exact value at x=%g differs from manuscript value'%xx
    assert abs(np.exp(-2.5)-0.0821)<5e-5
    print('PASS bench_schemes: exact values match the manuscript (1.7615, 0.5923, 0.0959; front 0.0821); schemes converge monotonically with orders in [0.4,1.2]; away from the front orders are 1.0 (upwind) and 2.0 (Lax-Wendroff)')
