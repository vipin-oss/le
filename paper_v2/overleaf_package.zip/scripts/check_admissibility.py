"""Admissibility of the heat-flux template G(s) = (k(1+tT s) + ks(1+tv s)/s)/(1+tq s)   [uncoupled thermal mode].
(1) Time-averaged dissipation  <-q theta_x> ~ Re G(i w) >= 0.   Closed form checked symbolically:
        Re G(i w) = [k + ks (tv - tq) + k tq tT w^2] / (1 + tq^2 w^2).
(2) Temporal stability of the mode exp(i k x + s t): roots of
        rho c tq s^3 + (rho c + K k tT) s^2 + K (k + ks tv) s + K ks = 0 ,  K = k_wave^2 ,
    Routh-Hurwitz (all coefficients > 0 and a2 a1 > a3 a0) is equivalent to
        rho c [k + ks (tv - tq)] + K k tT (k + ks tv) > 0   (given positive parameters).
    Checked against numerically computed roots on random parameter sets (no mismatch allowed)."""
import numpy as np, sympy as sp
w,k,ks,tq,tT,tv=sp.symbols('w k ks tq tT tv',positive=True)
s=sp.I*w
G=(k*(1+tT*s)+ks*(1+tv*s)/s)/(1+tq*s)
ReG=sp.simplify(sp.re(sp.expand_complex(G)))
claim=(k+ks*(tv-tq)+k*tq*tT*w**2)/(1+tq**2*w**2)
assert sp.simplify(ReG-claim)==0, 'closed form of Re G(iw) wrong'
print('Re G(i w) closed form verified symbolically')
# GN-II (k=0, tq=tT=tv=0): lossless
assert sp.simplify(sp.re(sp.expand_complex((ks/s))))==0
print('GN-II: Re G(i w) = 0 (lossless)')
rng=np.random.default_rng(1); mism=0; n_stab=0; n=0
for _ in range(20000):
    kk,kks,a,b,c=10**rng.uniform(-2,2,5); K=10**rng.uniform(-2,2); rc=10**rng.uniform(-1,1)
    tq_,tT_,tv_=a,b,c
    if rng.random()<0.3: tv_=0.0
    coeffs=[rc*tq_, rc+K*kk*tT_, K*(kk+kks*tv_), K*kks]
    r=np.roots(coeffs); stable=bool(np.all(r.real<1e-12))
    cond=rc*(kk+kks*(tv_-tq_))+K*kk*tT_*(kk+kks*tv_)>0
    n+=1; n_stab+=stable
    if stable!=cond: mism+=1
print('random sets: %d, stable %d, mismatches between Routh-Hurwitz condition and roots: %d'%(n,n_stab,mism))
assert mism==0 and 0.1*n<n_stab<0.9*n, 'condition disagrees with roots, or sample not informative'
# uncoupled DPL (ks=0): stable iff 1 + K k tT/(rho c) > 0, i.e. for tT>=0 always
for _ in range(2000):
    kk,a,b=10**rng.uniform(-2,2,3); K=10**rng.uniform(-2,2); rc=1.0
    r=np.roots([rc*a,rc+K*kk*b,K*kk]); assert np.all(r.real<0)
print('DPL (ks=0, tT>0): all roots in the open left half plane (2000 samples)')
print('PASS check_admissibility: Re G(i w) closed form and Routh-Hurwitz stability condition verified (0 mismatches)')
