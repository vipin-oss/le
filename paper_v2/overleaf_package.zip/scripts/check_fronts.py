import numpy as np
# high-frequency front speeds: LS: v^4 - v^2 (c1^2(1+eps)+cT^2) + c1^2 cT^2 = 0 ; GL: eps -> eps*tau1/tau0
eps=0.1; tau0=0.25; tau1=0.5; k=1.0
def roots_K(w,tau0,tauc,kind):
    s=-1j*w
    # (c1^2 K + s^2)(s(1+tau0 s)+kK)+ eps s K (1+tauc s)=0  (rho=c=c1=1)
    a=k; b=k*s**2+s*(1+tau0*s)+eps*s*(1+tauc*s); c=s**3*(1+tau0*s)
    d=np.sqrt(b*b-4*a*c); return [(-b+d)/(2*a),(-b-d)/(2*a)]
def speeds(w,tau0,tauc):
    K=roots_K(w,tau0,tauc,None); return sorted([w/np.sqrt(x).real if np.sqrt(x).real>0 else w/(-np.sqrt(x)).real for x in K])
cT2=k/tau0
for name,tauc in [('LS',tau0),('GL',tau1)]:
    e=eps*tauc/tau0
    pred=np.sqrt(np.roots([1,-((1+e)+cT2),cT2]).real)
    num=np.array(speeds(2e3,tau0,tauc)); prd=np.array(sorted(pred))
    print(name,'numerical v at w=2e3:',np.round(num,4),' predicted fronts:',np.round(prd,4))
    # tolerance 1e-3 relative: omega=2e3 is large but finite, so the numerical phase speed approaches the front speed with O(1/omega) corrections
    assert np.allclose(num,prd,rtol=1e-3), name+': numerical phase speed at w=2e3 differs from predicted front speed'
print('PASS check_fronts: LS and GL phase speeds at w=2e3 match the predicted front speeds (rtol 1e-3)')
