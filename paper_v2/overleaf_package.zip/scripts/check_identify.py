"""Identifiability of the heat law from dispersion data (template of Sec. 3).
(1) The coupled thermoelastic dispersion relation is LINEAR in G(s): G can be read off pointwise from a measured
    complex wavenumber of the elastic-type branch. (2) G depends on the five template parameters only through
    four combinations (k*tau_T, k+k* tau_v, k*, tau_q): the Jacobian has rank 4 and a known null direction.
(3) Synthetic noisy data: the four combinations are recovered, k and tau_v are not separable."""
import numpy as np
from scipy.optimize import least_squares
rho,c1,cv,beta,T0=1.0,1.0,1.0,np.sqrt(0.1),1.0           # eps = beta^2 T0/(rho^2 cv c1^2) = 0.1
def G(s,k,ks,tq,tT,tv): return (k*(1+tT*s)+ks*(1+tv*s)/s)/(1+tq*s)
def kroots(w,g):
    s=-1j*w; a=rho*c1**2*g; b=rho**2*c1**2*s*cv-rho*w**2*g+beta**2*T0*s; c=-rho**2*w**2*s*cv
    d=np.sqrt(b*b-4*a*c+0j); K=[(-b+d)/(2*a),(-b-d)/(2*a)]; ks_=[]
    for Kj in K:
        k=np.sqrt(Kj+0j); k=-k if (k.imag<0 or (abs(k.imag)<1e-14 and k.real<0)) else k; ks_.append(k)
    ks_.sort(key=lambda k: abs(k-w/c1)); return ks_[0]       # elastic-type branch
def invert(w,kmeas):
    s=-1j*w; K=kmeas**2
    return -s*((rho**2*c1**2*cv+beta**2*T0)*K-rho**2*w**2*cv)/(rho*K*(c1**2*K-w**2))
P0=np.array([1.0,0.3,0.25,0.4,0.2])                       # k, k*, tau_q, tau_T, tau_v
w=np.linspace(0.05,4.0,200)
kk=np.array([kroots(x,G(-1j*x,*P0)) for x in w])
Gx=G(-1j*w,*P0); Gr=invert(w,kk)
assert np.max(np.abs(Gr-Gx))<1e-9, np.max(np.abs(Gr-Gx))   # exact inversion (roundoff only)
# Jacobian of G(i w_j) w.r.t. the 5 parameters (complex G split into Re, Im), relative scaling
def vec(P): g=G(-1j*w[::10],*P); return np.r_[g.real,g.imag]
J=np.array([(vec(P0+h)-vec(P0-h))/(2*h[i]) for i,h in enumerate(np.diag(P0*1e-6))]).T
J=J*P0                                                      # columns scaled by parameter value
sv=np.linalg.svd(J,compute_uv=False)
assert sv[3]/sv[0]>1e-4 and sv[4]/sv[0]<1e-8, sv          # rank 4 of 5
n=np.array([1.0,0,0,-P0[3]/P0[0],-1.0/P0[1]])             # null direction: dk, d tau_T=-tau_T dk/k, d tau_v=-dk/k*
assert np.linalg.norm(J@(n*1e0/P0)) < 1e-6*np.linalg.norm(J@(np.array([0,1.0,0,0,0])/P0)), 'null direction'
dk=0.1; P1=np.array([P0[0]+dk,P0[1],P0[2],P0[0]*P0[3]/(P0[0]+dk),P0[4]-dk/P0[1]])   # different k, tau_T, tau_v
assert np.max(np.abs(G(-1j*w,*P0)-G(-1j*w,*P1)))<1e-12     # identical G: k and tau_v cannot be separated
# noisy synthetic data: 0.5 % relative noise on complex k at 12 frequencies
rng=np.random.default_rng(7); wn=np.linspace(0.3,3.5,12); kn=np.array([kroots(x,G(-1j*x,*P0)) for x in wn])
kn=kn*(1+0.005*(rng.standard_normal(12)+1j*rng.standard_normal(12))); Gn=invert(wn,kn)
def model(q):   # q = (a2=k*tau_T, a1=k+k* tau_v, a0=k*, tau_q): G = (a2 s^2 + a1 s + a0)/(s (1+tau_q s))
    s=-1j*wn; return (q[0]*s**2+q[1]*s+q[2])/(s*(1+q[3]*s))
res=least_squares(lambda q: np.r_[(model(q)-Gn).real/np.abs(Gn),(model(q)-Gn).imag/np.abs(Gn)],[0.1,0.5,0.2,0.2])
q0=np.array([P0[0]*P0[3],P0[0]+P0[1]*P0[4],P0[1],P0[2]])
rel=np.abs(res.x-q0)/q0; assert rel[2]<0.05 and rel[3]<0.05 and rel[1]<0.2 and rel[0]<0.4, rel   # a0, tau_q well, a1 fair, k*tau_T poorly
print('PASS check_identify: G recovered from complex k to 1e-9; Jacobian rank 4 of 5 (singular values %s); combinations recovered within %s with 0.5%% noise'%(np.array2string(sv/sv[0],precision=1),np.array2string(rel,precision=3)))
