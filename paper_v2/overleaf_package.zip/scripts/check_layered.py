"""Layered-medium surface waves: Rayleigh, Stoneley, Love, Scholte (isothermal elastic baseline).
Independent solution of the secular equations; compared with values printed in the original papers
(Rayleigh 1885, Stoneley 1924, Love 1911)."""
import numpy as np
from scipy.optimize import brentq

# ---------- 1. Rayleigh (1885): incompressible limit and compressible cases ----------
x=np.roots([1,-8,24,-16]); xr=x[np.abs(x.imag)<1e-9].real
assert len(xr)==1 and abs(xr[0]-0.91275)<2e-4, xr      # Rayleigh eq (25): k^2=.91275 (f^2+g^2)
c_inc=np.sqrt(xr[0]); assert abs(c_inc-0.9553)<2e-4
def rayleigh(nu):
    g=(1-2*nu)/(2*(1-nu))                       # beta^2/alpha^2
    F=lambda y: (2-y)**2-4*np.sqrt(1-y)*np.sqrt(1-g*y)   # y=c^2/beta^2
    return np.sqrt(brentq(F,1e-9,1-1e-12))
cr={nu:rayleigh(nu) for nu in (0.5-1e-9,0.25,0.0)}
printed={0.5-1e-9:0.9554,0.25:0.9194,0.0:0.8741}  # Rayleigh p.10 table values
for nu,v in printed.items(): assert abs(cr[nu]-v)<5e-4,(nu,cr[nu],v)
print('Rayleigh: incompressible c/beta=%.4f; nu=.25 %.4f; nu=0 %.4f'%(c_inc,cr[0.25],cr[0.0]))

# ---------- 2. Stoneley (1924): two welded half-spaces, full 4x4 interface determinant ----------
def stoneley_det(c,m1,m2):
    """m=(rho,alpha,beta); wave exp[ik(x-ct)], k=1; medium 1 in z>0, medium 2 in z<0; real form."""
    rows=[]; cols=[]
    def block(m,sg):
        rho,al,be=m; mu=rho*be**2; lam=rho*(al**2-2*be**2)
        r=np.sqrt(1-c**2/al**2); s=np.sqrt(1-c**2/be**2)
        ux=[1,-sg*s]; uz=[-sg*r,1]
        szz=[-lam*c**2/al**2+2*mu*r**2,-2*mu*sg*s]
        sxz=[-2*sg*r*mu,mu*(s**2+1)]
        return np.array([ux,uz,szz,sxz])
    return np.linalg.det(np.hstack([block(m1,+1),-block(m2,-1)]))
def stoneley_root(m1,m2,n=4000):
    top=min(m1[2],m2[2]); cs=np.linspace(1e-4,top*(1-1e-9),n); f=[stoneley_det(c,m1,m2) for c in cs]
    out=[]
    for i in range(n-1):
        if f[i]*f[i+1]<0: out.append(brentq(stoneley_det,cs[i],cs[i+1],args=(m1,m2)))
    return out
# Stoneley's printed value (p.422) refers to incompressible media (alpha/beta -> infinity, as in Rayleigh's
# own examples). The independent determinant reproduces it in that limit and gives the qualitative picture
# for finite compressibility: one real root, slightly below the common shear speed, increasing with alpha/beta.
rts=[]
for ratio in (1.5,np.sqrt(3.0),3.0,10.0,50.0,1e3):
    rr=stoneley_root((8.2,ratio,1.0),(3.2,ratio,1.0)); assert len(rr)==1,(ratio,rr); rts.append(rr[0])
assert all(np.diff(rts)>0) and 0.985<rts[0], rts
assert abs(rts[-1]-0.99287)<2e-5, rts[-1]                 # printed c = .99287 beta
# printed non-existence case (p.423): rho1 = 2 rho2, beta2^2 = 2 beta1^2 (incompressible)
big=1e3
nr=stoneley_root((2.0,big,1.0),(1.0,big*np.sqrt(2),np.sqrt(2)))
assert nr==[], nr
# Stoneley wave must be slower than both shear speeds and (here) faster than the Rayleigh speed of either medium
print('Stoneley: c/beta for alpha/beta=1.5..50: %s (printed .99287 at alpha/beta -> inf); non-existence case: no root'%np.round(rts,5))

# ---------- 3. Love (1911): layer 0<z<T on a half-space z<0 ----------
def love(kT,b1,b2,mu_ratio,mode=0,n=4000):
    """c in (b1,b2): tan(kT*q1)=mu_ratio*q2/q1, q1=sqrt(c^2/b1^2-1), q2=sqrt(1-c^2/b2^2); mode index by branch."""
    F=lambda c: np.sin(kT*np.sqrt(c**2/b1**2-1))*np.sqrt(c**2/b1**2-1)-mu_ratio*np.sqrt(1-c**2/b2**2)*np.cos(kT*np.sqrt(c**2/b1**2-1))
    cs=np.linspace(b1*(1+1e-9),b2*(1-1e-9),n); f=np.array([F(c) for c in cs]); out=[]
    for i in range(n-1):
        if f[i]*f[i+1]<0: out.append(brentq(F,cs[i],cs[i+1]))
    return out
b1,b2,mr=1.0,2.0,2.0                  # layer slower than substrate (existence condition b2>b1, Love p.162)
for mode in range(3): pass
low=[love(kT,b1,b2,mr)[0] for kT in (0.05,0.5,1,2,5,20,60)]
assert all(np.diff(low)<0), low                           # fundamental mode decreases monotonically with kT
assert low[0]>1.99*b1 and abs(low[-1]-b1)<0.03*b1, low    # -> b2 as kT->0, -> b1 as kT->inf
assert love(3.0,b1,b2*0.9999,mr)[0]>b1 and not love(3.0,2.0,1.0,1.0)  # no Love wave if layer faster than substrate
ncut=lambda kT: len(love(kT,b1,b2,mr))
assert ncut(0.5)==1 and ncut(5)>=3 and ncut(20)>ncut(5)   # higher modes appear as kT grows
print('Love: fundamental c/b1 = %s for kT=%s; mode counts %d,%d,%d'%(np.round(low,3),(0.05,0.5,1,2,5,20,60),ncut(0.5),ncut(5),ncut(20)))

# ---------- 4. Scholte-Stoneley: liquid half-space z>0 on solid half-space z<0 ----------
def scholte_det(c,rf,cf,rho,al,be):
    mu=rho*be**2; lam=rho*(al**2-2*be**2); r=np.sqrt(1-c**2/al**2); s=np.sqrt(1-c**2/be**2); rfp=np.sqrt(1-c**2/cf**2)
    # unknowns A_f, A_s, Bt_s  (solid in z<0: sg=-1)
    sg=-1
    uz=[-sg*r,1]; szz=[-lam*c**2/al**2+2*mu*r**2,-2*mu*sg*s]; sxz=[-2*sg*r*mu,mu*(s**2+1)]
    M=np.array([[-rfp,-uz[0],-uz[1]],[-rf*c**2,-szz[0],-szz[1]],[0,sxz[0],sxz[1]]])
    return np.linalg.det(M)
rf,cf,rho,al,be=1000.0,1480.0,7800.0,5960.0,3260.0        # water on steel (typical handbook values)
cR=be*rayleigh((al**2-2*be**2)/(2*(al**2-be**2)))
cs=np.linspace(50,min(cf,cR)*(1-1e-9),6000); f=[scholte_det(c,rf,cf,rho,al,be) for c in cs]
sr=[brentq(scholte_det,cs[i],cs[i+1],args=(rf,cf,rho,al,be)) for i in range(len(cs)-1) if f[i]*f[i+1]<0]
assert len(sr)==1 and sr[0]<cf and sr[0]<cR and sr[0]>0.9*cf, sr
print('Scholte (water/steel): c=%.1f m/s = %.4f c_water; Rayleigh speed of steel %.0f m/s'%(sr[0],sr[0]/cf,cR))
print('check_layered: Rayleigh, Stoneley (printed 0.99287 and non-existence case), Love (limits, mode counts) and Scholte-type roots verified')
