"""Schematic geometries of the atlas problems A1-A14 (original drawings, not copied from sources)."""
import numpy as np, matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Wedge, FancyArrowPatch
from fig_common import save, C
BL,OR,GR,GY='#0072B2','#D55E00','#009E73','#666666'
def arr(ax,p,q,c=BL,lw=1.4,ls='-'):
    ax.add_patch(FancyArrowPatch(p,q,arrowstyle='-|>',mutation_scale=8,color=c,lw=lw,linestyle=ls))
def half(ax,tag,hatch=True):
    ax.add_patch(Rectangle((-1.5,-1.4),3,1.4,fc='#EEF3F8',ec='#9AA7B4',lw=.8,hatch='//' if hatch else None))
    ax.plot([-1.5,1.5],[0,0],c='k',lw=1.6); ax.set_xlim(-1.5,1.5); ax.set_ylim(-1.4,1.5); ax.axis('off')
    ax.set_title(tag,fontsize=9,loc='left',pad=2,fontweight='bold')
def surface(ax):
    x=np.linspace(-1.2,1.2,100); 
    for d,a in [(0,.35),(.3,.2),(.6,.1)]:
        ax.plot(x,-d+a*np.cos(5*x)*0.5,c=BL,lw=1,alpha=1-d)
    arr(ax,(-.5,.55),(.6,.55)); ax.text(0,.7,r'$k$',ha='center',fontsize=7.5); arr(ax,(1.25,0),(1.25,-1.0),GY,.8); ax.text(1.38,-.55,'$z$',fontsize=7.5)
def refl(ax,inc,n,lab):
    arr(ax,(-1.1,1.1),(-.1,.05),OR,1.6); ax.text(-1.4,1.15,inc,fontsize=7.5,color=OR)
    ang=np.linspace(30,150,n) if n>1 else [90]
    for a,l in zip(np.linspace(55,150,n),lab):
        r=1.15; arr(ax,(-.1,.05),(-.1+r*np.cos(np.radians(180-a+0)),.05+r*np.sin(np.radians(a))*0+ .05+ r*np.sin(np.radians(180-a))*0.9),BL,1.2,'--' if l[0]=='T' else '-')
    ax.text(1.4,1.0,'\n'.join(lab),fontsize=7.5,color=BL,va='top',ha='right')
fig,axs=plt.subplots(4,4,figsize=(6.3,8.4)); axs=axs.ravel()
# A1,A2 surface wave
for i,(t,s) in enumerate([('A1','Rayleigh-type,\nradiation BC'),('A2','Rayleigh,\ninsulated')]):
    ax=axs[i]; half(ax,t); surface(ax); ax.text(-.1,-1.2,s,ha='center',fontsize=7.5,bbox=dict(fc='white',ec='none',pad=1.2))
# A3,A4 isothermal/insulated
for i,(t,s) in enumerate([('A3',r'isothermal: $\theta=0$'),('A4',r'insulated: $\partial_z\theta=0$')]):
    ax=axs[2+i]; half(ax,t); surface(ax); ax.text(-.1,-1.2,s,ha='center',fontsize=7.5,bbox=dict(fc='white',ec='none',pad=1.2))
    ax.plot([-1.5,1.5],[0,0],c=OR if i==0 else GR,lw=2.5,alpha=.8)
# A5 SH graded piezo half space
ax=axs[4]; half(ax,'A5',False)
for k in range(8): ax.add_patch(Rectangle((-1.5,-1.4+k*.175),3,.175,fc=plt.cm.Blues(.15+.09*(7-k)),ec='none',alpha=.9))
ax.plot([-1.5,1.5],[0,0],c='k',lw=1.6); arr(ax,(-.6,.5),(.6,.5)); ax.text(0,.65,r'SH, $k$',ha='center',fontsize=7.5)
ax.text(-.2,.1,r'$\odot\ u_3$',fontsize=7.5,color=OR); arr(ax,(1.25,-.1),(1.25,-1.2),GY,.8); ax.text(.55,-.75,'graded in $x_2$;\nmetalized\nor free',fontsize=7.5,color='k')
# A6 graded plate
ax=axs[5]; ax.axis('off'); ax.set_xlim(-1.5,1.5); ax.set_ylim(-1.4,1.3); ax.set_title('A6',fontsize=9,loc='left',pad=2,fontweight='bold')
for k in range(6): ax.add_patch(Rectangle((-1.4,-.5+k*.17),2.8,.17,fc=plt.cm.Greens(.15+.12*k),ec='none'))
ax.plot([-1.4,1.4],[-.5,-.5],c='k',lw=1.4); ax.plot([-1.4,1.4],[.52,.52],c='k',lw=1.4); arr(ax,(-.7,.85),(.7,.85)); ax.text(0,1.0,r'Lamb-type, $k$',ha='center',fontsize=7.5)
ax.text(0,-1.0,'piezoelectric--\npiezomagnetic,\nthickness-graded',ha='center',fontsize=7.5)
# A7 spherical curved plate
ax=axs[6]; ax.axis('off'); ax.set_xlim(-1.5,1.5); ax.set_ylim(-1.4,1.3); ax.set_title('A7',fontsize=9,loc='left',pad=2,fontweight='bold')
ax.add_patch(Wedge((0,-1.2),1.9,40,140,width=.45,fc='#CFE8D5',ec='k',lw=1)); arr(ax,(-.7,.85),(.7,.85)); ax.text(0,1.0,r'Lamb-like, curved',ha='center',fontsize=7.5)
ax.text(0,-.9,'graded piezoelectric\nshell sector',ha='center',fontsize=7.5)
# A8..A12 reflection
specs=[('A8','P in, insulated,\ninitial stress',['P','SV','T-wave']),('A9','SV in, insulated,\ninitial stress',['P','SV','T-wave']),('A10','qP in, SrTiO$_3$',['qP','qSV']),('A11','qSV in, $\\theta_0\\leq28^\\circ$ (see text)',['qP','qSV']),('A12','P in, hygrothermal',['P','SV','T','M'])]
for j,(t,s,lab) in enumerate(specs):
    ax=axs[7+j]; half(ax,t); arr(ax,(-1.2,1.15),(-.1,.03),OR,1.8)
    n=len(lab)
    for q,l in enumerate(lab):
        xe=-.1+ (.35+.3*q); ye=1.15-.1*q
        arr(ax,(-.1,.03),(xe+.35,ye),BL if l[0] not in 'TM' else GR,1.2,'--' if l[0] in 'TM' else '-')
    ax.text(0.2,-.25,s,fontsize=7.5,ha='center'); ax.text(1.45,1.2,', '.join(lab),fontsize=7.5,ha='right',color=BL)
# A13: half-space x>=0 (boundary drawn vertical), harmonic normal stress, B along z, fibres along x
ax=axs[12]; ax.axis('off'); ax.set_xlim(-1.5,1.5); ax.set_ylim(-1.4,1.3); ax.set_title('A13',fontsize=9,loc='left',pad=2,fontweight='bold')
ax.add_patch(Rectangle((-.5,-1.2),1.9,2.3,fc='#EEF3F8',ec='#9AA7B4',hatch='//'))
ax.plot([-.5,-.5],[-1.2,1.1],c='k',lw=1.6)
for yy in np.linspace(-.9,.6,5): arr(ax,(-1.3,yy),(-.55,yy),OR,1.2)
ax.text(-1.45,1.2,r'$\sigma_{xx}=P^*e^{\omega t+iby}$',fontsize=7.5,color=OR)
for yy in (-.6,0,.6): ax.plot([-.3,1.2],[yy,yy],c=GR,lw=1,ls=(0,(4,2)))
ax.text(.35,.18,'fibres $\\parallel x$',fontsize=7.5,color=GR,bbox=dict(fc='white',ec='none',pad=1))
ax.text(.35,-.45,r'$\odot\ \mathbf{H}\parallel z$, gravity',fontsize=7.5,bbox=dict(fc='white',ec='none',pad=1))
ax.text(.45,-1.3,'$x\\geq0$; internal heat source $Q$',fontsize=7.5,ha='center',bbox=dict(fc='white',ec='none',pad=1))
# A14 harmonic surface stress
ax=axs[13]; half(ax,'A14')
for xx in np.linspace(-1.1,1.1,7): arr(ax,(xx,.75),(xx,.05),OR,1.2)
ax.text(0,.9,r'$\sigma_0 e^{i\omega t}$',ha='center',fontsize=7.5,color=OR); ax.text(-1.35,-.65,'6mm (CdSe),\n$T=0$ at surface',fontsize=7.5)
# legend panels
ax=axs[14]; ax.axis('off'); ax.set_xlim(0,1); ax.set_ylim(0,1)
arr(ax,(.05,.85),(.3,.85),OR,1.8); ax.text(.35,.83,'incident / driving',fontsize=7.5)
arr(ax,(.05,.65),(.3,.65),BL,1.4); ax.text(.35,.63,'wave (mechanical)',fontsize=7.5)
arr(ax,(.05,.45),(.3,.45),GR,1.2,'--'); ax.text(.35,.43,'thermal / moisture mode',fontsize=7.5)
ax.text(.05,.2,'Schematic, not to scale.\nDrawn from the problem\ndescription in each source.',fontsize=7.5,color=GY)
axs[15].axis('off')
B=dict(fc='white',ec='none',pad=1.2,alpha=.9)
for ax in axs:
    for t in ax.texts:
        if t.get_position()[1]<0.0 or t.get_text().startswith(('P in','SV in','qP','qSV in','fibre','6mm')): 
            if t.get_color()!=BL: t.set_bbox(B)
fig.tight_layout(); save(fig,'fig_atlas_geometry')
