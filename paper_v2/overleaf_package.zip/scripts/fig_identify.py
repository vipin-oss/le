"""Heat law read off from synthetic complex wavenumbers; singular values of the parameter Jacobian."""
import numpy as np, matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from fig_common import *
import warnings; warnings.filterwarnings('ignore')
src=open('check_identify.py').read()
ns={}; exec(src.split('# noisy synthetic data')[0],ns)
G,kroots,invert,P0,w,sv=ns['G'],ns['kroots'],ns['invert'],ns['P0'],ns['w'],ns['sv']
rng=np.random.default_rng(7); wn=np.linspace(0.3,3.5,12); kn=np.array([kroots(x,G(-1j*x,*P0)) for x in wn])
kn=kn*(1+0.005*(rng.standard_normal(12)+1j*rng.standard_normal(12))); Gn=invert(wn,kn)
fig,ax=plt.subplots(1,2,figsize=(7.4,3.0))
wf=np.linspace(0.05,4,300); Gf=G(-1j*wf,*P0)
ax[0].plot(wf,Gf.real,c=C['LS'],label=r'Re $G$ (exact)'); ax[0].plot(wf,Gf.imag,c=C['DPL'],label=r'Im $G$ (exact)')
ax[0].plot(wn,Gn.real,'o',c=C['LS'],ms=3.5); ax[0].plot(wn,Gn.imag,'s',c=C['DPL'],ms=3.5)
ax[0].set_xlabel(r'$\omega/\omega_*$'); ax[0].set_ylabel(r'$G(-\mathrm{i}\omega)/k$'); ax[0].legend(frameon=False,fontsize=7.5)
ax[0].set_title(r'$G$ read off from $0.5\,\%$-noisy complex $k$',fontsize=8.5)
ax[1].semilogy(range(1,6),sv/sv[0],'o-',c=C['GN']); ax[1].set_xticks(range(1,6)); ax[1].set_xlabel('singular value index'); ax[1].set_ylabel('relative size')
ax[1].set_title(r'Jacobian of $G$ w.r.t. $(k,k^*,\tau_q,\tau_T,\tau_v)$',fontsize=8.5)
fig.tight_layout(); save(fig,'fig_identify'); print('ok')
