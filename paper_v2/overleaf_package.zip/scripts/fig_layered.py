"""Love-wave dispersion (layer on half-space) and Stoneley existence region (incompressible media)."""
import numpy as np, matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from fig_common import *
import importlib.util, os
src=open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'check_layered.py')).read()
ns={}; exec(src.split('# ---------- 1.')[0]+'\n'+'def stoneley_det'+src.split('def stoneley_det')[1].split('# Stoneley\'s printed value')[0]+'\ndef love'+src.split('def love')[1].split('b1,b2,mr=')[0],ns)
love=ns['love']; stoneley_root=ns['stoneley_root']
fig,ax=plt.subplots(1,2,figsize=(6.3,3.1))
b1,b2,mr=1.0,2.0,2.0
kT=np.linspace(0.05,12,500); modes=[[] for _ in range(4)]
for t in kT:
    r=sorted(love(t,b1,b2,mr))                       # ascending: mode 0 has the lowest c; new modes enter at c=beta2
    for i in range(4): modes[i].append(r[i] if i<len(r) else np.nan)
for i,m in enumerate(modes): ax[0].plot(kT,m,color=plt.cm.viridis(i/4.0),label=f'mode {i}')
ax[0].axhline(b1,c='k',lw=.6,ls=':'); ax[0].axhline(b2,c='k',lw=.6,ls=':'); ax[0].set_xlabel(r'$kT$'); ax[0].set_ylabel(r'$c/\beta_1$')
ax[0].set_title(r'Love waves, $\beta_2/\beta_1=2$, $\mu_2/\mu_1=2$',fontsize=9); ax[0].legend(frameon=False,fontsize=8)
rr=np.logspace(-1,1,48); mm=np.logspace(-1,1,48); Z=np.zeros((len(mm),len(rr)))
for i,m in enumerate(mm):
    for j,r in enumerate(rr):
        rho1,rho2=r,1.0; mu1,mu2=m,1.0
        Z[i,j]=len(stoneley_root((rho1,1e3,np.sqrt(mu1/rho1)),(rho2,1e3,np.sqrt(mu2/rho2)),n=300))
ax[1].pcolormesh(rr,mm,Z,shading='auto',cmap='Blues',vmin=0,vmax=1.6)
ax[1].set_xscale('log'); ax[1].set_yscale('log'); ax[1].set_xlabel(r'$\rho_1/\rho_2$'); ax[1].set_ylabel(r'$\mu_1/\mu_2$')
ax[1].set_title('Stoneley wave exists (dark), incompressible',fontsize=9)
for a_ in ax: a_.grid(alpha=.25)
fig.tight_layout(); save(fig,'fig_layered'); print('fig_layered saved; existence fraction %.2f'%Z.mean())
