"""Histogram of publication years of the works cited in this review (from refs*.bib and main.aux).
This is a count of CITED works, not a bibliometric survey of the field."""
import re, glob, collections, sys
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
root = sys.argv[1] if len(sys.argv) > 1 else '..'
aux = open(f'{root}/main.aux', encoding='utf8', errors='ignore').read()
cited = set()
for m in re.finditer(r'\\citation\{([^}]*)\}', aux):
    cited.update(k.strip() for k in m.group(1).split(','))
years = {}
for f in glob.glob(f'{root}/refs*.bib'):
    t = open(f, encoding='utf8', errors='ignore').read()
    for m in re.finditer(r'@\w+\s*\{\s*([^,\s]+)\s*,(.*?)(?=\n@|\Z)', t, flags=re.S):
        y = re.search(r'\byear\s*=\s*[{"]?\s*(\d{4})', m.group(2))
        if y: years.setdefault(m.group(1), int(y.group(1)))
ys = [years[k] for k in cited if k in years]
print('cited keys', len(cited), 'with year', len(ys), 'range', min(ys), max(ys))
dec = collections.Counter((y // 5) * 5 for y in ys)
xs = sorted(dec)
fig, ax = plt.subplots(figsize=(6.3, 3.0))
eras=[(0,1950,'#7F7F7F','before 1950'),(1950,1990,'#0072B2','1950-1989'),(1990,2010,'#E69F00','1990-2009'),(2010,2030,'#009E73','2010 onward')]
def col(x):
    for lo,hi,c,_ in eras:
        if lo<=x<hi: return c
ax.bar([x + 2.5 for x in xs], [dec[x] for x in xs], width=4.2, color=[col(x) for x in xs])
from matplotlib.patches import Patch
ax.legend(handles=[Patch(color=c,label=l) for _,_,c,l in eras],frameon=True,facecolor='white',edgecolor='none',framealpha=1,loc='upper left',fontsize=8)
ax.set_xlabel('Publication year (5-year bins)'); ax.set_ylabel('Cited works')
ax.set_xlim(1830, 2030); ax.set_yticks([0,25,50,75,100]); ax.set_ylim(0,112); ax.grid(axis='y', lw=0.3)
for s in ('top', 'right'): ax.spines[s].set_visible(False)
fig.tight_layout(); fig.savefig(f'{root}/figs/fig_refyears.pdf')
open(f'{root}/figs/fig_refyears_stats.txt', 'w').write(f'{len(ys)} cited works with year, {min(ys)}-{max(ys)}; since 1990: {sum(y>=1990 for y in ys)}; since 2010: {sum(y>=2010 for y in ys)}; since 2020: {sum(y>=2020 for y in ys)}\n')
print(open(f'{root}/figs/fig_refyears_stats.txt').read())
