import pymupdf,sys,collections
d=pymupdf.open(sys.argv[1]); bad={}
for i,p in enumerate(d,1):
    sizes=collections.Counter()
    for b in p.get_text('dict')['blocks']:
        for l in b.get('lines',[]):
            for s in l['spans']:
                if s['text'].strip(): sizes[round(s['size'],1)]+=len(s['text'])
    if sizes:
        small=sum(c for sz,c in sizes.items() if sz<6.0)
        if small>15: bad[i]=(min(sizes),small)
print(len(bad),'pages with >15 chars below 6 pt'); print(bad)
