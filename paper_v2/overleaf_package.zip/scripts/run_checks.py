"""Run all verification scripts and write a pass/fail log (checks_log.txt). Exit code 1 if any script fails."""
import subprocess,sys,platform,datetime
import numpy,scipy,sympy,mpmath
names=['check_dispersion','check_admissibility','check_layered','check_identify','check_reductions','check_thermopiezo','check_fronts','check_gn2','check_kk','check_bg','bench_laplace','bench_schemes']
lines=['checks run %s'%datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d %H:%M UTC'),
 'python %s numpy %s scipy %s sympy %s mpmath %s'%(platform.python_version(),numpy.__version__,scipy.__version__,sympy.__version__,mpmath.__version__)]
bad=0
for n in names:
    r=subprocess.run([sys.executable,n+'.py'],capture_output=True,text=True)
    ok=(r.returncode==0 and 'PASS' in r.stdout)
    last=[l for l in r.stdout.splitlines() if l.startswith('PASS')]
    lines.append('%s %s rc=%d %s'%('PASS' if ok else 'FAIL',n,r.returncode,(last[-1][5:] if last else r.stderr.strip().splitlines()[-1:] )))
    bad+=0 if ok else 1
open('checks_log.txt','w').write('\n'.join(map(str,lines))+'\n'); print('\n'.join(map(str,lines)))
sys.exit(1 if bad else 0)
