# Source package: reproduction and limitations

**Work in progress, not submission-ready.** The accompanying `paper_v2/main.pdf`
is the original 119-page build, not a build of these amended sources. The updated sources and figures have not been compiled into a PDF. Do not treat it as the final manuscript.

The archive now includes the 23 PDF figures referenced by the manuscript, plus
PNG renderings. They were generated using the supplied scripts; this does not
establish that they reproduce the figures in the original PDF. The Lamb figure uses a fallback root-search guess at one point; the full branch
still requires independent verification.

## Run

Install Python 3 and numpy, scipy, matplotlib, sympy and mpmath. The audit used
Python 3.11.2, numpy 2.4.6, scipy 1.17.1, matplotlib 3.11.2, sympy 1.14.0 and
mpmath 1.3.0. From this directory:

```sh
python3 scripts/reproduce.py
pdflatex -interaction=nonstopmode -halt-on-error main.tex
bibtex main
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
```

Each script writes a
log under `reproduction_logs/`. Exit zero does not prove a printed calculation
is correct; inspect results independently. Some scripts write output relative to
their current directory, so the harness runs each from `scripts/`.

The original sources omit `refwork/lines.txt` and `refwork/inventory_dec.csv`,
which `scripts/gen_refs_new.py` requires. Do not run it without restoring the
original inputs. `scripts/gen_catalogue.py` overwrites the catalogue based on
title keywords; it is not a relevance or citation-verification tool. Both are
excluded from the harness.

The build requires a TeX Live installation with pdflatex, BibTeX, the packages
used by main.tex, and `unsrtnat.bst`. A TeX build could not be performed in this
sandbox; no assertion is made about a new page count or errors in the revised
sources. See `../CHANGELOG.md` outside the archive for the audit details and
remaining work.
