"""Run every figure/check/bench script and archive everything it prints in numbers_log.txt,
so that each number quoted in the text can be traced to a printed line (section markers: '### script')."""
import subprocess,sys,glob,os,warnings
skip={'fig_common','models','run_checks','archive_numbers','gen_catalogue','gen_refs_new','interface_te'}
names=sorted(os.path.basename(f)[:-3] for f in glob.glob('*.py'))
out=[]
for n in names:
    if n in skip: continue
    r=subprocess.run([sys.executable,'-W','ignore',n+'.py'],capture_output=True,text=True)
    out.append('### %s rc=%d'%(n,r.returncode)); out.append(r.stdout.rstrip())
    if r.returncode: out.append('STDERR: '+r.stderr.strip().splitlines()[-1] if r.stderr.strip() else '')
open('numbers_log.txt','w').write('\n'.join(out)+'\n')
print('wrote numbers_log.txt', sum(1 for l in out if l.startswith('### ')),'scripts')
