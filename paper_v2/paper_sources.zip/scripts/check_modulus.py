"""Effective longitudinal modulus m(s)=w^2/K of the coupled wave: quadratic in m,
   rho*R*m^2 - [rho*R*c1^2 + rho*G(s)*s + b2T0] m + rho*c1^2*G(s)*s = 0   (R=rho*c_v, b2T0=beta^2 T0),
equivalent to the dispersion polynomial; checks (i) equality of roots with w^2/K from models.coupled_k2,
(ii) analyticity of the elastic-type root for Re s>0 (no root crossing) for admissible template models,
(iii) the weak-coupling limit m = c1^2 + b2T0 c1^2/(rho(R c1^2 - G s))  (first order in b2T0)."""
import numpy as np, warnings
warnings.filterwarnings('ignore')
from models import *
rho,R,c1=1.3,0.9,1.1
for b2 in [0.0,0.05,0.4]:
  for name in ['Fourier','LS','DPL','GN-III','MGT']:
    p=model(name,tau=0.7)
    worst=0
    for w in np.logspace(-2,2,41):
        s=-1j*w; g=G(s,p)
        m=np.roots([rho*R,-(rho*R*c1**2+rho*g*s+b2),rho*c1**2*g*s])
        K=np.array(coupled_k2(w,p,rho,R,c1,b2))
        mK=w**2/K
        d=max(min(abs(mm-mk) for mk in mK) for mm in m)
        worst=max(worst,d/np.max(abs(m)))
    assert worst<1e-10,(name,b2,worst)
# analyticity: discriminant of the quadratic has no zero for Re s>0 (checked on a grid) for k>0 models
b2=0.4
for name in ['Fourier','LS','DPL','GN-III','MGT']:
    p=model(name,tau=0.7); mind=1e9
    for sr in np.logspace(-3,2,60):
        for si in np.linspace(-50,50,201):
            s=sr+1j*si; g=G(s,p); A=rho*R; B=-(rho*R*c1**2+rho*g*s+b2); C=rho*c1**2*g*s
            mind=min(mind,abs(B*B-4*A*C)/(abs(B)**2+abs(A*C)))
    assert mind>1e-6,(name,mind)
# weak coupling
p=model('Fourier'); b2=1e-6
for w in [0.1,1,10]:
    s=-1j*w; g=G(s,p)
    mr=np.roots([rho*R,-(rho*R*c1**2+rho*g*s+b2),rho*c1**2*g*s])
    m=mr[np.argmin(abs(mr-c1**2))]
    ap=c1**2+b2*c1**2/(rho*(R*c1**2-g*s))
    assert abs(m-ap)<1e-9,(w,m,ap)
# LS: high-frequency roots equal the front relation m^2 - [c1^2 + cT^2 + b2/(rho R)] m + c1^2 cT^2 = 0, cT^2 = k/(tau0 R)
p=model('LS',tau=0.7); b2=0.4; s=-1j*1e7; g=G(s,p)
mr=np.sort(np.roots([rho*R,-(rho*R*c1**2+rho*g*s+b2),rho*c1**2*g*s]).real)
cT2=p['k']/(p['tq']*R); mf=np.sort(np.roots([1,-(c1**2+cT2+b2/(rho*R)),c1**2*cT2]).real)
assert np.allclose(mr,mf,rtol=1e-5),(mr,mf)
print('PASS check_modulus: quadratic modulus relation reproduces the dispersion roots to 1e-10; no branch point for Re s>0 on the grid; weak-coupling limit matches; LS high-frequency roots equal the front relation')
