"""Thermoelastic Lamb (plate) problem, plane strain, plate -h<y<h, traction-free, insulated or isothermal faces.
Same nondimensionalisation as fig_rayleigh.py (rho=1, lambda+2mu=1, c_v=1, k_cond=1, T0=1, beta^2=eps).
Each of the three modes (two dilatational-thermal, one shear) contributes exp(+-m y); 6x6 determinant."""
import numpy as np, mpmath as mp
mp.mp.dps=30
nu=0.3; cs2=(1-2*nu)/(2-2*nu); mu=cs2; lam=1-2*mu
def modes(s,eps,G):
    a=G; b=-(G*s**2+s+eps*s); c=s**3
    d=mp.sqrt(b*b-4*a*c); return [(-b+d)/(2*a),(-b-d)/(2*a)]
def det6(s,k,h,eps,G=1,bc='ins'):
    beta=mp.sqrt(eps); I=mp.mpc(0,1)
    kap=modes(s,eps,G); th=[(kk-s**2)/beta for kk in kap]
    ms=[mp.sqrt(kk+k**2) for kk in kap]; msh=mp.sqrt(s**2/cs2+k**2)
    cols=[]
    for sgn in (+1,-1):                       # exp(-sgn*m*y): sgn=+1 decaying with y
        for j in range(2):
            m=sgn*ms[j]
            col=lambda y,m=m,j=j:[ (lam*kap[j]+2*mu*m**2-beta*th[j])*mp.e**(-m*y),
                                   (-2*mu*I*k*m)*mp.e**(-m*y),
                                   ((-m*th[j]) if bc=='ins' else th[j])*mp.e**(-m*y)]
            cols.append(col)
        m=sgn*msh
        cols.append(lambda y,m=m:[ (2*mu*I*k*m)*mp.e**(-m*y), (mu*(m**2+k**2))*mp.e**(-m*y), 0*y])
    M=mp.matrix(6,6)
    for c,col in enumerate(cols):
        top=col(h); bot=col(-h)
        for r in range(3): M[r,c]=top[r]; M[r+3,c]=bot[r]
    return mp.det(M)
def solve_s(k,h,eps,guess,G=1,bc='ins'):
    f=lambda s: det6(s,k,h,eps,G,bc)
    return mp.findroot(f,guess,solver='muller',tol=1e-20,maxsteps=100)
if __name__=='__main__':
    # elastic limit: eps=1e-8, kh=0.3, h=1; compare the antisymmetric root of the 6x6 determinant with the
    # Rayleigh-Lamb equation  (q^2-k^2)^2 tanh(P h) = 4 k^2 P Q tanh(Q h)  (P,Q = evanescent decay rates) solved separately.
    h=mp.mpf(1); k=mp.mpf('0.3'); cL2=lam+2*mu; cT2=mu
    def F(w):
        P=mp.sqrt(k*k-w*w/cL2); Q=mp.sqrt(k*k-w*w/cT2)
        return (Q*Q+k*k)**2*mp.tanh(P*h)-4*k*k*P*Q*mp.tanh(Q*h)
    wex=mp.re(mp.findroot(F,0.0443,tol=1e-25))
    g=mp.mpc(0,-wex)
    s=mp.findroot(lambda s: det6(s,k,h,1e-8,1,'ins'),(g*1.001,g*0.999),solver='secant',tol=1e-20,maxsteps=120)
    w=complex(1j*s); d=abs(w.real-float(wex))
    print('Rayleigh-Lamb A0 at kh=0.3: omega = %.11f ; plate determinant at eps=1e-8: %.11f ; difference %.1e'%(wex,w.real,d))
    assert d<1e-10
    print('PASS lamb_te: plate determinant reproduces the exact Rayleigh-Lamb A0 root to %.0e in the elastic limit'%1e-10)
