#!/usr/bin/env python3
"""Run the supplied numerical/figure scripts, capturing output, not judging its truth.

Usage from the source root: python3 scripts/reproduce.py [log-directory]
A nonzero exit means at least one script failed or timed out. Inspect the logs
as well: many historical checks only print their results and do not assert.
The bibliography/catalogue generators are intentionally excluded: one requires
missing input data and the other overwrites the manuscript catalogue.
"""
from pathlib import Path
import os
import subprocess
import sys

scripts = Path(__file__).resolve().parent
out = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else scripts.parent / 'reproduction_logs'
out.mkdir(parents=True, exist_ok=True)
patterns = ('check_*.py', 'bench_*.py', 'fig_*.py', 'table_*.py')
files = {p for pattern in patterns for p in scripts.glob(pattern)}
files.discard(scripts / 'fig_common.py')
files.update(scripts / n for n in ('worked_examples.py', 'interface_te.py', 'lamb_te.py'))
env = dict(os.environ, MPLBACKEND='Agg')
failed = []
for path in sorted(files):
    try:
        result = subprocess.run([sys.executable, path.name], cwd=scripts, env=env,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                text=True, timeout=300, check=False)
        output, status = result.stdout, result.returncode
    except subprocess.TimeoutExpired as exc:
        output = (exc.stdout or b'').decode(errors='replace') if isinstance(exc.stdout, bytes) else (exc.stdout or '')
        output += '\nTIMED OUT after 300 seconds\n'
        status = 124
    (out / (path.stem + '.log')).write_text(output, encoding='utf-8')
    print(f'{path.name}: exit {status}', flush=True)
    if status:
        failed.append(path.name)
print(f'Logs: {out}; failures: {", ".join(failed) if failed else "none"}')
sys.exit(bool(failed))
