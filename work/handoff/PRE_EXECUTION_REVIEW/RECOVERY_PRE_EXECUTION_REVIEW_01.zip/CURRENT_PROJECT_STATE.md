# Current project state pointer

Read MASTER_PROMPT.md (v2.1), then PROJECT_STATE_PRE_EXECUTION_REVIEW_01.md and the root decision/status files. No numbered research phase has been fully approved/completed; current bounded source review is PARTIAL. Do not start simulations automatically.
