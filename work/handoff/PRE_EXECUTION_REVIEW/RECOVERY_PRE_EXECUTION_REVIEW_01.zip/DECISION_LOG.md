# Decision log

Date:30 September2026.

## D001 — Current master
Previous working rules:v2.0 and unapproved amendment suggestions. New decision:user supplied FINAL MASTER PROMPTv2.1; preserve it verbatim as canonical MASTER_PROMPT.md, sections0–90. Evidence:user message. Affected science/code/results:none. No scientific revalidation caused by saving the control text.

## D002 — Scope and execution gate
User confirmed BOTH material/crystal and geometric symmetry and COUPLED THERMOELASTIC RESPONSE. User subsequently asked for published-journal/benchmark evidence review before execution. Current authorization is that bounded review, not automatic implementation/pilot/production. Final direction/model/material/journal remain unapproved.

## D003 — Evidence classification
Limiting-case and theoretical comparisons are verification, not automatically physical validation. Experimental property inputs do not independently validate a new model when copied into it. Agreeing with a source is not guaranteed or to be forced.

## D004 — Source integrity
Current review found2019 correction DOI10.1063/1.5088513 to Jiang2018 DOI10.1063/1.5054573. Future use must include corrected version and coordinate mapping. The beta-Ga2O3/new-model proposal remains provisional. Affected current equations/code/results:none because no new model was implemented/run. Recheck/revalidate any future input derived from that source.

## D005 — Source-access blocker
Core recent-model/coupled benchmark full equations are not obtained. Do not invent them from abstracts or silently substitute an older model. Request legitimate PDFs and exact next-task approval. Journal-family checks are provisional, not final submission selection.
