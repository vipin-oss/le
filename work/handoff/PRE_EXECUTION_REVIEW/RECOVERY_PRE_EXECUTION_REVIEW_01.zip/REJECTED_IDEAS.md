# Rejected shortcuts / held options

Date:30 September2026. No user-approved research direction was rejected or replaced.

Rejected shortcuts:
- Calling a limiting/numerical/theoretical comparison physical validation by default.
- Copying experimental conductivity into a model and treating that same-data equality as independent physical validation.
- Using an uncorrected2018 tensor or mixing crystal-coordinate frames.
- Treating an axisymmetric isotropic/radially orthotropic reference as a fixed-Cartesian monoclinic solution.
- Treating a different source BC/finite-vs-infinite geometry as a matched case without an explicit map.
- Claiming Q1/JCR/SCIE as a single unqualified property or using journal prestige as proof of scientific correctness.
- Inventing inaccessible recent-model operators/parameters/results or guaranteeing a benchmark match.

Held, not globally rejected:beta-Ga2O3/model/cavity suggestion pending reconstructable equations/data, novelty, significance and user approval. All concerns are revisitable with evidence.
