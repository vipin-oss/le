# Research profile — observed and pending

Date:30 September2026. Status:input-grounded working record, not an approved complete project profile.

User-confirmed current aim:recent heat-conduction model; coupled thermoelastic response; BOTH material/crystal symmetry and geometric symmetry. Q1/SCI is target positioning under MASTER_PROMPTv2.1, not a guarantee.

Observed inputs:published bibliography, eight supplied unpublished PDFs, eight representative accessible published full texts, and FEM4 MATLAB source/result/manuscript package. Their provenance/inventories are preserved. Paper ownership/publication status and manuscript claims are not universally independently certified.

Observed infrastructure:static2D C1 BFS electromechanical/strain-gradient MATLAB program, not an existing transient thermal solver. Three Python figure helpers are also supplied. Method/language preference is not confirmed; do not force BFS/FEM/MATLAB.

Provisional direction only:2025 generalized CV/GN family with monoclinic beta-Ga2O3 and circular/elliptical cavity symmetry mismatch. Novelty/model/direction/journal approval:NOT_GRANTED.

Unknown:user hardware/compute, installed scientific runtimes/licences, experimental access, deadline, costs/APC preferences, intended exact Google Drive source, final material/model branch and research-type evidence route. Do not fill these from assumptions or repository names.

Default production approval thresholds:4CPU-hours,1GPU-hour,5GB generated data (ANY exceeded requires explicit approval). No user override or production approval.
